/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consumo;

import java.util.*;

/**
 *
 * @author Mario
 */
public class Consumo {

    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        double km_total = 0;
        int litros_total = 0;
        
        String resp = "S";
        do {
            System.out.print("Digite a quilometragem: ");
            double km = ent.nextDouble();
            km_total += km;
        
            System.out.print("Digite os litros: ");
            int litros = ent.nextInt();
            litros_total += litros;
        
            //System.out.printf("Consumo: %5.2f km/l\n\n", km / litros);
            System.out.println("Consumo: " + km / litros);

            System.out.printf("Total de Km     : %5.2f km/l\n", km_total);
            System.out.printf("Média de consumo: %5.2f km/l\n", 
                    km_total / litros_total);
           
            System.out.print("Deseja continuar (S/N)? ");
            resp = ent.next();
            
        } while (resp.toUpperCase().equals("S"));
    }
    
}
